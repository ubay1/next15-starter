(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__06dc72c5._.css",
  "static/chunks/node_modules_@tanstack_query-devtools_build_6de832df._.js",
  "static/chunks/node_modules_343c6e0d._.js",
  "static/chunks/src_69ab6c51._.js"
],
    source: "dynamic"
});
